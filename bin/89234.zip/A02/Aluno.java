package A02;

public class Aluno extends A02E01{
	double notaT;
	double notaP;
}
