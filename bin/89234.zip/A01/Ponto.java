package A01;

public class Ponto extends A01E06 {
	double x, y;
}
