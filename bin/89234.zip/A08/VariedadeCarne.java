package A08;

public enum VariedadeCarne {
	Vaca, Porco, Peru, Frango, Outra;
}
