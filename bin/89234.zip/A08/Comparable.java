package A08;

public interface Comparable {
	public abstract Prato ordenar();
}
