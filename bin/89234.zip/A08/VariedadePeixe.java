package A08;

public enum VariedadePeixe {
	Congelado, Fresco;
}
