package A08;

public class PratoDieta extends Prato{

	public PratoDieta(String nome, double maxCalorias) {
		super(nome, maxCalorias);
		// TODO Auto-generated constructor stub
	}

}
