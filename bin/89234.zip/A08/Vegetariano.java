package A08;

public interface Vegetariano {
	
}
