package A07;

public interface IDemo2 {
	public abstract void metodo21();
	public abstract void metodo22();
}
