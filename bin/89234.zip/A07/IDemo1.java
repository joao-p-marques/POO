package A07;

public interface IDemo1 {
	public abstract void metodo11();
	public abstract void metodo12();
}
