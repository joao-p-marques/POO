package A07;

public interface IDemo3 {
	public abstract void metodo31();
	public abstract void metodo32();
}
