package A07;

public interface IDemo123 extends IDemo1, IDemo2, IDemo3{
	public abstract void metodo123();
}
