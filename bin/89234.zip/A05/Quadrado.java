package A05;

public class Quadrado extends Retangulo {

	public Quadrado(Ponto centro, String cor, int lado) {
		super(centro, cor, lado, lado);
	}

}
